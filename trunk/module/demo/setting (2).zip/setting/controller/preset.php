<?php
/*$v_id = '1';
$v_cond['pre_id'] = $v_id;
$v_pre_det = \E::get( 'obj_system_module')->_get($v_cond);

$v_var["pre_name"]= (isset($v_pre_det["pre_name"]) && $v_pre_det["pre_name"]!="")? $v_pre_det["pre_name"]:"";*/

// echo \V::load_view( $this->get_view_file_path('menu','share');exit();
\V::append_data( 'menu', \V::load_view( $this->get_view_file_path('menu','share'), $v_object, $v_var ) );
\V::append_data( 'body', \V::load_view( $this->get_view_file_path(), $v_object, $v_var ) );
\V::output_view();
?>