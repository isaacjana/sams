<h3 class="mb-4" style="padding-left: 10px; padding-top: 10px"><u>Preset Document</u></h3>
<div class='card mb-4'>
    <div class="card-body">
        <div class="form-group row">
            <label for="pre_name" class="col-sm-2 col-form-label"><?php echo \E::get('obj_system_lang')->get('SETTING_FORM_NAME'); ?></label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="pre_name" id="pre_name" placeholder="Document Name" value="<?php echo \U::safe_display_string(isset($v_pre_name) ? $v_pre_name : "");?>">
            </div>
        </div>
        <div class="form-group row">
            <div class="col-sm-2"></div>
            <div class="col-sm-10">
                <a href="javascript:search();" class="btn btn-primary" role="button">
                    <i class="fa fa-fw fa-search"></i>&nbsp;<?php echo \E::get('obj_kernel_lang')->get('BTN_SUBMIT'); ?>
                </a>
                <a href="javascript:rec_list('')" class="btn btn-danger" role="button">
                    <i class="fa fa-fw fa-times"></i>&nbsp;<?php echo \E::get('obj_kernel_lang')->get('BTN_RESET'); ?>
                </a>
            </div>
        </div>
    </div>
</div>