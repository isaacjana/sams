<h2 class="mb-4 bg-grey p-2">User Access</h2>
<?PHP
    \I::load_error("MESSAGE");

?>
<div class="p-2">
    <div class="card mb-4">
        <div class="card-body">
            <h5>New User</h5>
            <?php
            if (isset($v_test)) {
                echo $v_test;
            }
            ?> 
            <div class="p-4">
                <form id="frm_acl" name="frm_acl" method="post" onsubmit="return validate(this);" enctype="multipart/form-data">
                    <div class="form-group row">
                        <label for="user_role" class="col-sm-2 col-form-label"><?PHP echo \E::get('obj_system_lang')->get('USER_GROUP_NAME'); ?></label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control compulsary" name="user_role" id="user_role" placeholder="User Role" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="group_level" class="col-sm-2 col-form-label"><?PHP echo \E::get('obj_system_lang')->get('USER_GROUP_LEVEL'); ?></label>
                        <div class="col-sm-10">
                            <?php
                                $v_opt = '';
                                $v_count = 1;
                                foreach($v_code_role as $v_row){
                                    if($v_count==1){
                                        $v_opt .= '<option value="'.\U::safe_display_string($v_row["role_id"]).'" selected>'.\U::safe_display_string($v_row["role_name"]).'</option>';    
                                    }else{
                                        $v_opt .= '<option value="'.\U::safe_display_string($v_row["role_id"]).'">'.\U::safe_display_string($v_row["role_name"]).'</option>';
                                    }
                                    ++$v_count;
                                }
                                ?>
                                <select class="form-control" id="group_level" name="group_level">
                                    <?php
                                    if($v_opt!=''){
                                        echo $v_opt;
                                    }
                                    ?>
                                </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10"></div>
                        <div class="col-sm-2 text-right">
                            <a href="javascript:if(validate(document.frm_acl)) document.frm_acl.submit();" class="btn btn-primary" role="button">
                                <i class="fa fa-fw fa-save"></i>&nbsp;<?php echo \E::get('obj_kernel_lang')->get('BTN_SAVE'); ?>
                            </a>
                        </div>
                    </div>
                </form>
            </div>
            
        </div>
        <?PHP
            \I::load_error();
        ?>
    </div>
    <div class="card mb-4">
        <div class="card-body">
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Group</th>
                        <th>Level</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tfoot class="tfootClass">
                    <tr>
                        <th></th>
                        <th>Group</th>
                        <th>Level</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
                <tbody>
                <?php
                    if($v_group_list_info && is_array($v_group_list_info)){
                        $v_tips_read = \E::get('obj_kernel_lang')->get('READ');
                        $v_tips_edit = \E::get('obj_kernel_lang')->get('EDIT');
                        $v_tips_delete = \E::get('obj_kernel_lang')->get('DELETE');
                        
                        $v_count = 1;
                        foreach($v_group_list_info as $v_row){
                            $v_class = ( $v_count%2 == 1 ) ? "odd" : "normal";

                            echo '<tr 
                                id="row'.$v_count.'"
                                onMouseOver="record_listing_highlight( this, \'highlight\' )"
                                onMouseOut ="record_listing_highlight( this, \'' . $v_class . '\' )"
                                onClick    ="record_listing_click_tr ( this, \'' . $v_class . '\', \'chkRow'.$v_count.'\' )"
                                ondblclick = "window.location=\''.\E::get('obj_curr_module')->build_action_path('user','view',$v_row['group_id']).'\'"
                            
                            >';
                            echo '<th scope="row" align="left">' . $v_count . '</th>';
                            echo '<td align="left" data-title="ic_no">' . $v_row['kwd_value'] . '</td>';
                            echo '<td align="left" data-title="group">' . $v_row['role_name'] . '</td>';

                            echo '<td align="center" valign="top" data-title="'.\E::get( 'obj_system_lang')->get('ACTION').'">';
                            echo '<a title="'.$v_tips_read .'" href="'.\E::get( 'obj_curr_module')->build_action_path('setting','useraccess_view',$v_row['group_id']).'">';
                            echo '<i class="fa fa-fw fa-eye"></i></a>';

                            echo '<a title="'.$v_tips_edit.'" href="'.\E::get( 'obj_curr_module')->build_action_path('user','edit',$v_row['group_id']).'">';
                            echo '<i class="fa fa-fw fa-edit"></i></a>';

                            echo '<a class="danger" title="'.$v_tips_delete.'" href="javascript:del_confirm(\'' . \U::safe_display_string($v_row['group_id']).'\')">';
                            echo '<i class="fa fa-fw fa-trash-alt"></i></a>';

                            echo '</td>';
                            echo '</tr>';
                            
                            ++$v_count;
                        }
                    }else{
                        echo '<tr><td colspan="7" align="center">'. \E::get( 'obj_kernel_lang')->get('MSG_NO_RECORD_FOUND') . '</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        
        // Setup - add a text input to each footer cell
        $('#example tfoot th').not(":eq(0),:eq(9)").each( function () {
            var title = $(this).text();
            $(this).html( '<input type="text" class="search_input tfootInput"  style="color:#000" />' );
        });

        $('#example').DataTable({
            "pageLength" : 6,
            "bProcessing": true,
            "order": [],
            "bLengthChange": false, //disable the entries
            "bFilter": true,
            "bInfo": false,
            "bAutoWidth": true,
            "sDom": '<"H"lTr><"datatable-scroll"t><"F"ip>' //disable search box
        });

        // DataTable
        var table = $('#example').DataTable();

        // Apply the search
        table.columns().every( function () {
          var that = this;

          $( 'input', this.footer() ).on( 'keyup change', function () {
              if ( that.search() !== this.value ) {
                  that
                      .search( this.value )
                      .draw();
              }
          });
        });

    }); 
</script>
