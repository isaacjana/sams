<h3 class="mb-4" style="padding-left: 10px; padding-top: 10px"><u>Running Number</u></h3>
<div class='card mb-4'>
    <div class="card-body">
        <table id="tbl_responsive" cellpadding="0" cellspacing="0" border="0" class="table" width="100%">
            <thead>
                <tr>
                    <th><?php echo \E::get( 'obj_curr_module_lang')->get('SETTING_RUN_NAME'); ?></th>
                    <th><?php echo \E::get( 'obj_curr_module_lang')->get('SETTING_PREFIX'); ?></th>
                    <th><?php echo \E::get( 'obj_curr_module_lang')->get('SETTING_NEXT_NUM'); ?></th>
                    <th><?php echo \E::get( 'obj_curr_module_lang')->get('SETTING_DIGIT_NUM'); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo \E::get( 'obj_curr_module_lang')->get('SETTING_RUN_DOC_NAME'); ?></td>
                    <td><input type="text" class="text" name="" id="" value="" style="width:400px;"/></td>
                    <td><input type="text" class="text" name="" id="" value="" style="width:400px;"/></td>
                    <td><input type="text" class="text" name="" id="" /></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="form-group row">
        <div class="col-sm-2"></div>
        <div class="col-sm-10">
            <a href="javascript:search();" class="btn btn-primary" role="button">
                <i class="fa fa-fw fa-search"></i>&nbsp;<?php echo \E::get('obj_kernel_lang')->get('BTN_SUBMIT'); ?>
            </a>
            <a href="javascript:rec_list('')" class="btn btn-danger" role="button" style="float: right">
                <i class="fa fa-fw fa-times"></i>&nbsp;<?php echo \E::get('obj_kernel_lang')->get('BTN_RESET'); ?>
            </a>
        </div>
    </div>    
</div>
