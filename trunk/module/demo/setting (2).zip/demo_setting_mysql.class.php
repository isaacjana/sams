<?php
namespace moonlight\demo;

class demo_setting_mysql {
	private $co_db_root;

	public function __call($name, $arguments){
		$v_tmp_arr = explode("_", $name);
		$v_call_obj = $v_tmp_arr[0];
		if(isset($this->co_db_root)){
			return call_user_func_array(array($this->co_db_root, $name), $arguments);
		}
	}

	public function __construct( &$p_co_db ){
		$this->co_db_root = $p_co_db;
	}

	public function setting_user_list(){
		// Default Language
		$v_lang_info = \E::get('obj_curr_module')->get_lang();

		// QUERY - Coding
		$v_query = 	"SELECT 
						*
					FROM " . $this->get_db_table_prefix() . "sys_user
					WHERE _rec_status='SHOW'
					ORDER BY usr_id DESC";					

		$v_result = $this->co_db_root->execute_query($v_query);

		return $v_result;
	}

	public function setting_user_detail( $p_id ){
		// Default Language
		$v_lang_info = \E::get('obj_curr_module')->get_lang();

		// QUERY - Coding
		$v_query = 	"SELECT 
						*
					FROM " . $this->get_db_table_prefix() . "sys_user
					WHERE usr_id=\"" . \U::safe_sql_string( $p_id ) . "\"
					";	

		$v_result = $this->co_db_root->execute_query($v_query);

		return $v_result[0];
	}

	public function setting_user_group_get( $p_id ){
		// Default Language
		$v_lang_info = \E::get('obj_curr_module')->get_lang();

		// QUERY - acl group table
		$v_query = 	"SELECT 
						*
					FROM " . $this->get_db_table_prefix() . "demo_acl_group 
					WHERE _rec_status = \"SHOW\" 
					AND group_id=\"" . \U::safe_sql_string( $p_id ) . "\"
					";
		$v_result = $this->co_db_root->execute_query($v_query);
		if($v_result && is_array($v_result)){
			foreach($v_result as $v_key=>$v_value){
				$v_result[$v_key]['_rec_modified_on'] = $this->co_db_root->__to_display_date($v_result[$v_key]['_rec_modified_on']);
			}
		}

		// QUERY - label table
		$v_query = 	"SELECT 
						kwd_lang,
						kwd_value
					FROM " . $this->get_db_table_prefix() . "demo_acl_group_lbl l
					LEFT JOIN " . $this->get_db_table_prefix() . "demo_acl_group g
					ON g.group_id = l.kwd_code
					WHERE g._rec_status = \"SHOW\" 
					AND g.group_id=\"" . \U::safe_sql_string( $p_id ) . "\"
					";
		$v_result_lbl = $this->co_db_root->execute_query($v_query);

		if($v_result_lbl && is_array($v_result_lbl)){
			foreach($v_result_lbl as $v_value){
				$v_result[0]['kwd_value'][$v_value['kwd_lang']] = $v_value['kwd_value'];
			}
		}

		return $v_result;
	}

	public function setting_user_acl_get( $p_id ){
		// Default Language
		$v_lang_info = \E::get('obj_curr_module')->get_lang();
		// QUERY - acl group table
		$v_query = 	"SELECT 
						*
					FROM " . $this->get_db_table_prefix() . "demo_acl_user_group 
					WHERE _rec_status = \"SHOW\" 
					AND usr_id=?
					AND 1=?
					";
		$this->co_db_root->set_prepare_statement($v_query);

		$v_param[0]['data_type'] = 'str';
		$v_param[0]['data'] =  $p_id;
		$v_param[1]['data_type'] = 'int';
		$v_param[1]['data'] =  1;

		$this->co_db_root->bind_param($v_param);
		$v_result = $this->co_db_root->execute_statement();
		if($v_result && is_array($v_result)){
			$v_result[0]['_rec_modified_on'] = $this->co_db_root->__to_display_date($v_result[0]['_rec_modified_on']);
		}

		return $v_result;

	}


	/*
	 * Function to add user acl
	 */
	public function setting_user_acl_add( $p_value ){
		$v_query = 	"INSERT INTO 
					" . $this->get_db_table_prefix() . "demo_acl_user_group(
						usr_id,
						group_id,
						usr_news_notification,
						_rec_created_on,
						_rec_created_by,
						_rec_modified_on,
						_rec_modified_by,
						_rec_status
					)VALUE(
						\"" . \U::safe_sql_string( $p_value['usr_id'] ) . "\",
						\"" . \U::safe_sql_string( $p_value['usr_group'] ) . "\",
						\"" . \U::safe_sql_string( $p_value['usr_news_notification'] ) . "\",
						\"" . \U::safe_sql_string( $p_value['current_datetime'] ) . "\",
						\"" . \U::safe_sql_string( $p_value['current_usr_id'] ) . "\",
						\"" . \U::safe_sql_string( $p_value['current_datetime'] ) . "\",
						\"" . \U::safe_sql_string( $p_value['current_usr_id'] ) . "\",
						\"" . \U::safe_sql_string( $p_value['_rec_status'] ) . "\"
					)";
		$v_result = $this->co_db_root->execute_query($v_query);
		return $this->co_db_root->get_last_insert_id();
	}

	/*
	 * Function to update user acl details
	 */
	public function setting_user_acl_edit( $p_value ){
		$v_query = 	"UPDATE 
						" . $this->get_db_table_prefix() . "demo_acl_user_group 
					SET
						group_id = \"" . \U::safe_sql_string( $p_value['usr_group'] ) . "\", 
						usr_news_notification = \"" . \U::safe_sql_string( $p_value['usr_news_notification'] ) . "\", 
						_rec_modified_on = \"" . \U::safe_sql_string( $p_value['current_datetime'] ) . "\",
						_rec_modified_by = \"" . \U::safe_sql_string( $p_value['current_usr_id'] ) . "\"
					WHERE 
						usr_id = \"" . \U::safe_sql_string( $p_value['id'] ) . "\"
					";
		$v_result = $this->co_db_root->execute_query($v_query);
	}

	public function setting_group_list(){
		// Default Language
		$v_lang_info = \E::get('obj_curr_module')->get_lang();

		// QUERY - Coding
		$v_query = 	"SELECT 
						*
					FROM " . $this->get_db_table_prefix() . "demo_acl_group_lbl l
					LEFT JOIN " . $this->get_db_table_prefix() . "demo_acl_group g
					ON g.group_id = l.kwd_code
					LEFT JOIN " . $this->get_db_table_prefix() . "code_role c
					ON g.group_level = c.role_id
					WHERE g._rec_status = \"SHOW\"
					AND l.kwd_lang=\"".$v_lang_info."\"
					ORDER BY l.kwd_code DESC";					

		$v_result = $this->co_db_root->execute_query($v_query);

		return $v_result;
	}

	public function setting_group_add($p_value){
		$v_fields_list='group_level,';
		$v_value_list='"' . \U::safe_sql_string( $p_value['usr_role'] ) . '", ';
		for($v_c=0; $v_c<$p_value['comp_count']; $v_c++){
			$v_fields_list .= 'group_com_' . \U::safe_sql_string( $p_value['acl'][$v_c]['name'] ) . ', ';
			$v_value_list .= '"' . \U::safe_sql_string( $p_value['acl'][$v_c]['value'] ) . '", ';
		}

		$v_query = 	"INSERT INTO 
						" . $this->get_db_table_prefix() . "demo_acl_group(
						" . $v_fields_list . "
						_rec_created_on,
						_rec_created_by,
						_rec_modified_on,
						_rec_modified_by,
						_rec_status
					)VALUE(
						" . $v_value_list . "
						\"" . \U::safe_sql_string( $p_value['current_datetime'] ) . "\",
						\"" . \U::safe_sql_string( $p_value['current_usr_id'] ) . "\",
						\"" . \U::safe_sql_string( $p_value['current_datetime'] ) . "\",
						\"" . \U::safe_sql_string( $p_value['current_usr_id'] ) . "\",
						\"" . \U::safe_sql_string( $p_value['_rec_status'] ) . "\"
					)";
		$v_result = $this->co_db_root->execute_query($v_query);
		return $this->co_db_root->get_last_insert_id();
		// return $v_query;
	}

	public function setting_group_lbl_add( $p_value ){
		$v_rec_value="(
					\"" . \U::safe_sql_string( $p_value['id'] ) . "\",
					\"" . \U::safe_sql_string( $p_value['current_datetime'] ) . "\",
					\"" . \U::safe_sql_string( $p_value['current_usr_id'] ) . "\",
					\"" . \U::safe_sql_string( $p_value['current_datetime'] ) . "\",
					\"" . \U::safe_sql_string( $p_value['current_usr_id'] ) . "\",
					";
		$v_rec_value_list = "";
		$v_lang_info = \E::get('obj_curr_module')->get_supported_lang();
		foreach($v_lang_info as $v_lang){
			if($v_rec_value_list!=""){
				$v_rec_value_list .= ",";
			}
			$v_rec_value_list .= $v_rec_value;
			$v_rec_value_list .= "\"" . \U::safe_sql_string( $v_lang ) . "\",";
			$v_rec_value_list .= "\"" . \U::safe_sql_string( $p_value['group_name'][$v_lang] ) . "\"";
			$v_rec_value_list .= ")";
		}

		$v_query = 	"INSERT INTO 
					" . $this->get_db_table_prefix() . "demo_acl_group_lbl(
						kwd_code,
						_rec_created_on,
						_rec_created_by,
						_rec_modified_on,
						_rec_modified_by,
						kwd_lang,
						kwd_value
					)VALUE{$v_rec_value_list}";

		$v_result = $this->co_db_root->execute_query($v_query);
	}

	public function setting_code_role(){
		// Default Language
		$v_lang_info = \E::get('obj_curr_module')->get_lang();

		// QUERY - Coding
		$v_query = 	"SELECT 
						*
					FROM " . $this->get_db_table_prefix() . "code_role
					ORDER BY role_id ASC";					

		$v_result = $this->co_db_root->execute_query($v_query);

		return $v_result;
	}
}
?>