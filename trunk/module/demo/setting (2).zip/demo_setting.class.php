<?php
namespace moonlight\demo;

class demo_setting {
	private $co_db;

	public function __construct( $p_co_db ){
		$this->co_db = $p_co_db;
	}

	public function __destruct(){
		unset($this->co_db);
	}

	public function setting_user_list(){
		return $this->co_db->setting_user_list();
	}

	public function setting_user_detail( $p_id ){
		return $this->co_db->setting_user_detail( $p_id );
	}

	public function setting_user_acl_get( $p_id ){
		return $this->co_db->setting_user_acl_get( $p_id );
	}

	public function setting_user_acl_add( $p_value ){
		$p_value['current_usr_id'] = \E::get_session('usr_id');
		$p_value['current_datetime'] = \E::get( 'obj_curr_module')->__now(); // Get the server date and time now
		$v_id = $this->co_db->setting_user_acl_add( $p_value );

		return $v_id;
	}

	public function setting_user_acl_edit( $p_value ){
		$p_value['current_usr_id'] = \E::get_session('usr_id');
		$p_value['current_datetime'] = \E::get( 'obj_curr_module')->__now(); // Get the server date and time now
		$this->co_db->setting_user_acl_edit( $p_value );
	}

	public function setting_user_group_get( $p_id ){
		return $this->co_db->setting_user_group_get( $p_id );
	}

	public function setting_group_list(){
		return $this->co_db->setting_group_list();
	}

	public function setting_code_role(){
		return $this->co_db->setting_code_role();
	}

	public function setting_group_add( $p_value ){
		for($v_c=0; $v_c<$p_value['comp_count']; $v_c++){
			$p_value['acl'][$v_c]['name'] = $p_value['comp_name_'.$v_c];

			unset($v_acl);
			$v_acl = Array(
						$p_value['group_del_'.$v_c],
						$p_value['group_edit_'.$v_c],
						$p_value['group_add_'.$v_c],
						$p_value['group_read_'.$v_c]
					);

			$v_tmp_val = implode( $v_acl );
			$v_acl_val = bindec( $v_tmp_val );
			$p_value['acl'][$v_c]['value'] = $v_acl_val;
		}

		$p_value['current_usr_id'] = \E::get_session('usr_id');
		$p_value['current_datetime'] = \E::get( 'obj_curr_module')->__now(); // Get the server date and time now

		$v_id = $this->co_db->setting_group_add( $p_value );

		return $v_id;
	}
	public function setting_group_lbl_add( $p_value ){
		$p_value['current_usr_id'] = \E::get_session('usr_id');
		$p_value['current_datetime'] = \E::get( 'obj_curr_module')->__now(); // Get the server date and time now
		$this->co_db->setting_group_lbl_add( $p_value );
	}
}

?>