<?php
class setting_en{
	function get_all_lang_var(){ return get_object_vars($this);	}

  /*User*/
  protected $SETTING_COMP_NAME = 'SETTING';
  protected $SETTING_FORM_NAME = 'Form Version No';
  protected $SETTING_NAME = 'User Name';
  protected $SETTING_RUN_NAME = 'Name';
  protected $SETTING_PREFIX = 'Prefix';
  protected $SETTING_NEXT_NUM = 'Next Number';
  protected $SETTING_DIGIT_NUM = 'Digit Number';
  protected $SETTING_RUN_DOC_NAME = 'Folio Number';
}
?>